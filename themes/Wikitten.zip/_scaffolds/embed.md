---
title: {{ title }}
date: {{ date }}
layout: embed
description: 
iframe_url: 
# You should creat embed_page folder which should have a "index.html"
# in this article`s asset folder without iframe_url.
---
